# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '296a9de8c878a5f85dd36913dce19d76e0fdfc8a42804f650151b7263f56aa5d77ad3424f018f9d1147681d9aab6a58ea91531b07cb9bc7dff63271828ecbd37'